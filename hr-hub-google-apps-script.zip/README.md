# HR Lounge Google Apps Script 배포본

사내 서버 없이 Google Workspace 계정으로 직원 전용 URL을 만들기 위한 Apps Script 버전입니다.

## 배포 방법

1. 회사 Google Workspace 계정으로 <https://script.google.com/home/projects/create> 접속
2. 기본 `Code.gs` 내용을 이 폴더의 `Code.gs`로 교체
3. 새 HTML 파일을 만들고 이름을 `Index`로 지정한 뒤, 이 폴더의 `Index.html` 내용을 붙여넣기
4. 프로젝트 설정에서 `appsscript.json` 표시를 켠 뒤, 이 폴더의 `appsscript.json` 내용으로 교체
5. `Deploy` > `New deployment` > 유형 `Web app` 선택
6. `Execute as`: `Me`
7. `Who has access`: `Anyone within <회사 도메인>`
8. 배포 후 생성되는 Web app URL을 직원들에게 공유

## 운영 메모

- `Execute as: Me`를 사용하면 정적 HR 홈페이지 열람만 하는 직원에게 별도 권한 승인 팝업이 뜨지 않는 편입니다.
- `Who has access`를 조직 내부로 제한해야 Google Workspace 로그인 기반 접근 제한이 됩니다.
- 상세 카드가 Google Docs, Drive, Sheet 등으로 연결될 경우, 해당 문서 자체의 공유 권한도 회사 내부로 제한해야 합니다.
- Apps Script가 꺼져 있는 조직은 Google Admin Console에서 Apps Script 사용이 허용되어야 합니다.
- 블로그 글은 `Script Properties`에 공유 저장됩니다. 배포 설정에서 조직 내부 접근으로 제한하면 직원은 열람할 수 있고, 글 작성/수정/삭제는 관리자 비밀번호를 아는 사람만 진행할 수 있습니다.
- 글 작성, 수정, 삭제는 관리자 비밀번호 `1966`을 입력해야 접근할 수 있습니다. 단순 프론트 잠금 방식이므로 외부 공개용 보안 장치로 사용하지 마세요.
