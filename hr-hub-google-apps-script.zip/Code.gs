const APP_TITLE = "HR Lounge";
const BLOG_STORE_PREFIX = "HR_LOUNGE_BLOG_STATE_V1_";
const BLOG_STORE_CHUNK_SIZE = 8000;

function doGet() {
  const template = HtmlService.createTemplateFromFile("Index");
  template.appTitle = APP_TITLE;
  template.userEmail = getActiveUserEmail_();

  return template
    .evaluate()
    .setTitle(APP_TITLE)
    .addMetaTag("viewport", "width=device-width, initial-scale=1")
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function getActiveUserEmail_() {
  try {
    return Session.getActiveUser().getEmail() || "";
  } catch (error) {
    return "";
  }
}

function getCurrentUser() {
  return {
    email: getActiveUserEmail_(),
  };
}

function getBlogState() {
  return readBlogStateFromProperties_(PropertiesService.getScriptProperties());
}

function saveBlogState(state) {
  const lock = LockService.getScriptLock();
  lock.waitLock(10000);

  try {
    const properties = PropertiesService.getScriptProperties();
    const previousState = readBlogStateFromProperties_(properties);
    const raw = JSON.stringify(state || {});

    if (raw.length > 450000) {
      throw new Error("저장할 수 있는 글 데이터 용량을 초과했습니다.");
    }

    const previousCount = Number(properties.getProperty(`${BLOG_STORE_PREFIX}COUNT`) || 0);
    for (let index = 0; index < previousCount; index += 1) {
      properties.deleteProperty(`${BLOG_STORE_PREFIX}${index}`);
    }

    const count = Math.ceil(raw.length / BLOG_STORE_CHUNK_SIZE);
    for (let index = 0; index < count; index += 1) {
      properties.setProperty(
        `${BLOG_STORE_PREFIX}${index}`,
        raw.slice(index * BLOG_STORE_CHUNK_SIZE, (index + 1) * BLOG_STORE_CHUNK_SIZE),
      );
    }
    properties.setProperty(`${BLOG_STORE_PREFIX}COUNT`, String(count));
    properties.setProperty(`${BLOG_STORE_PREFIX}UPDATED_AT`, new Date().toISOString());

    const notification = sendNewPostNotification_(previousState, state);

    return {
      ok: true,
      savedAt: properties.getProperty(`${BLOG_STORE_PREFIX}UPDATED_AT`),
      user: getActiveUserEmail_(),
      ...notification,
    };
  } finally {
    lock.releaseLock();
  }
}

function readBlogStateFromProperties_(properties) {
  const count = Number(properties.getProperty(`${BLOG_STORE_PREFIX}COUNT`) || 0);
  if (!count) {
    return null;
  }

  const chunks = [];
  for (let index = 0; index < count; index += 1) {
    chunks.push(properties.getProperty(`${BLOG_STORE_PREFIX}${index}`) || "");
  }

  const raw = chunks.join("");
  if (!raw) {
    return null;
  }

  try {
    return JSON.parse(raw);
  } catch (error) {
    return null;
  }
}

function sendNewPostNotification_(previousState, nextState) {
  const settings = getNotificationSettings_(nextState);
  if (!settings.enabled || !settings.emails.length) {
    return { notificationSent: false, notificationCount: 0 };
  }

  if (!previousState || !Array.isArray(previousState.posts) || !Array.isArray(nextState && nextState.posts)) {
    return { notificationSent: false, notificationCount: 0 };
  }

  const previousPostIds = new Set(previousState.posts.map((post) => String(post && post.id)).filter(Boolean));
  const newPosts = nextState.posts.filter((post) => post && post.id && !previousPostIds.has(String(post.id)));

  if (!newPosts.length) {
    return { notificationSent: false, notificationCount: 0 };
  }

  try {
    newPosts.forEach((post) => {
      MailApp.sendEmail({
        to: settings.emails.join(","),
        subject: `[${APP_TITLE}] 새 글이 등록되었습니다: ${post.title || "제목 없음"}`,
        body: buildNotificationBody_(post, nextState),
        name: APP_TITLE,
        noReply: true,
      });
    });

    return {
      notificationSent: true,
      notificationCount: settings.emails.length,
      notifiedPosts: newPosts.length,
    };
  } catch (error) {
    return {
      notificationSent: false,
      notificationCount: 0,
      notificationError: String(error && error.message ? error.message : error),
    };
  }
}

function getNotificationSettings_(state) {
  const notifications = state && state.siteSettings && state.siteSettings.notifications
    ? state.siteSettings.notifications
    : {};

  return {
    enabled: normalizeBoolean_(notifications.enabled),
    emails: parseEmailList_(notifications.emails),
  };
}

function normalizeBoolean_(value) {
  if (value === true) {
    return true;
  }

  const text = String(value || "").trim().toLowerCase();
  return ["true", "1", "yes", "on", "사용", "켜짐"].indexOf(text) >= 0;
}

function parseEmailList_(value) {
  const seen = {};
  return String(value || "")
    .split(/[\s,;]+/)
    .map((email) => email.trim().toLowerCase())
    .filter((email) => {
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || seen[email]) {
        return false;
      }
      seen[email] = true;
      return true;
    });
}

function buildNotificationBody_(post, state) {
  const url = buildPostUrl_(post);
  const category = getCategoryLabel_(state, post.category);
  const lines = [
    "HR Lounge에 새 글이 등록되었습니다.",
    "",
    `제목: ${post.title || "제목 없음"}`,
    `분류: ${category}${post.group ? ` / ${post.group}` : ""}${post.subcategory ? ` / ${post.subcategory}` : ""}`,
    `작성자: ${post.author || "People Team"}`,
  ];

  if (post.summary) {
    lines.push("", `요약: ${post.summary}`);
  }

  if (url) {
    lines.push("", `바로가기: ${url}`);
  }

  return lines.join("\n");
}

function buildPostUrl_(post) {
  try {
    const url = ScriptApp.getService().getUrl();
    return url && post && post.id ? `${url}#post/${encodeURIComponent(String(post.id))}` : "";
  } catch (error) {
    return "";
  }
}

function getCategoryLabel_(state, slug) {
  const category = state && state.siteSettings && state.siteSettings.categories
    ? state.siteSettings.categories[slug]
    : null;
  return category && category.label ? category.label : slug || "HR Lounge";
}
